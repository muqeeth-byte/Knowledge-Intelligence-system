"use client";

import { Search, X } from "lucide-react";

export function CommandPalette({ open, onClose, onNavigate }) {
  if (!open) return null;
  const commands = [
    ["Ask a question", "ask"],
    ["Ingest documents", "ingest"],
    ["Open knowledge graph", "graph"],
    ["Run diagnostics", "settings"],
    ["View analytics", "analytics"]
  ];
  return (
    <div className="paletteBackdrop" onClick={onClose}>
      <div className="palette" onClick={(event) => event.stopPropagation()}>
        <div className="paletteSearch">
          <Search size={18} />
          <input autoFocus placeholder="Type a command or search your workspace..." />
          <button onClick={onClose}>
            <X size={18} />
          </button>
        </div>
        <div className="paletteList">
          {commands.map(([label, target]) => (
            <button
              key={label}
              onClick={() => {
                onNavigate(target);
                onClose();
              }}
            >
              {label}
              <kbd>Enter</kbd>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
