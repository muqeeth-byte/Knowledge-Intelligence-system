import json
from io import BytesIO
from typing import Any

import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader


def extract_pdf(file_bytes: bytes) -> str:
    reader = PdfReader(BytesIO(file_bytes))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n\n".join(pages)


async def extract_url(url: str) -> tuple[str | None, str]:
    async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
        response = await client.get(url)
        response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()

    title = soup.title.string.strip() if soup.title and soup.title.string else None
    main = soup.find("main") or soup.body or soup
    text = main.get_text(" ", strip=True)
    return title, text


def _pick_json_path(payload: Any, json_path: str | None) -> Any:
    if not json_path:
        return payload
    current = payload
    for part in json_path.split("."):
        if isinstance(current, list):
            current = current[int(part)]
        elif isinstance(current, dict):
            current = current[part]
        else:
            raise ValueError(f"Cannot descend into JSON path segment '{part}'")
    return current


async def extract_api(endpoint: str, json_path: str | None = None) -> str:
    async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
        response = await client.get(endpoint)
        response.raise_for_status()
        payload = response.json()
    selected = _pick_json_path(payload, json_path)
    if isinstance(selected, str):
        return selected
    return json.dumps(selected, indent=2, ensure_ascii=True)
