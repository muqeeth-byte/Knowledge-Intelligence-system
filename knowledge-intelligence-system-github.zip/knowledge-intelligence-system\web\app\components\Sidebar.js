"use client";

import {
  BarChart3,
  BrainCircuit,
  DatabaseZap,
  GitBranch,
  Home,
  Layers3,
  Search,
  Settings,
  Sparkles,
  UploadCloud
} from "lucide-react";

const nav = [
  { id: "dashboard", label: "Dashboard", icon: Home },
  { id: "ingest", label: "Ingest", icon: UploadCloud },
  { id: "ask", label: "Ask AI", icon: BrainCircuit },
  { id: "graph", label: "Knowledge Graph", icon: GitBranch },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "settings", label: "Settings", icon: Settings },
  { id: "advanced", label: "Advanced", icon: Layers3 }
];

export function Sidebar({ active, onChange, collapsed, onToggle, connected }) {
  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <button className="brand" onClick={onToggle} aria-label="Toggle navigation">
        <span className="brandMark">KI</span>
        {!collapsed && (
          <span>
            <strong>Knowledge OS</strong>
            <small>Intelligence workspace</small>
          </span>
        )}
      </button>

      {!collapsed && (
        <label className="commandSearch">
          <Search size={16} />
          <input placeholder="Command palette" />
          <kbd>Ctrl K</kbd>
        </label>
      )}

      <nav>
        {nav.map((item) => {
          const Icon = item.icon;
          return (
            <button
              className={active === item.id ? "active" : ""}
              key={item.id}
              onClick={() => onChange(item.id)}
              title={item.label}
            >
              <Icon size={18} />
              {!collapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      <div className="sidebarFooter">
        <div className="statusOrb">
          <DatabaseZap size={18} />
          {!collapsed && (
            <span>
              <strong>{connected ? "API online" : "Demo mode"}</strong>
              <small>{connected ? "Live retrieval" : "Backend not public"}</small>
            </span>
          )}
        </div>
        {!collapsed && (
          <div className="agentPill">
            <Sparkles size={16} />
            Claude-ready reasoning
          </div>
        )}
      </div>
    </aside>
  );
}
