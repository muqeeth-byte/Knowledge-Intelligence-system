ANALYTICS_SERIES = [
    {"day": "Mon", "Documents": 12, "Queries": 31, "Citations": 84},
    {"day": "Tue", "Documents": 18, "Queries": 42, "Citations": 121},
    {"day": "Wed", "Documents": 16, "Queries": 55, "Citations": 138},
    {"day": "Thu", "Documents": 24, "Queries": 63, "Citations": 172},
    {"day": "Fri", "Documents": 31, "Queries": 76, "Citations": 214},
    {"day": "Sat", "Documents": 29, "Queries": 81, "Citations": 236},
]

RECENT_ACTIVITY = [
    {"type": "pdf ingested", "title": "Market intelligence packet", "timestamp": "demo"},
    {"type": "AI answer", "title": "What changed in customer churn risk?", "timestamp": "demo"},
    {"type": "url ingested", "title": "Competitive pricing update", "timestamp": "demo"},
]

SUGGESTED_PROMPTS = [
    "Summarize the strongest evidence across my knowledge base.",
    "What contradictions exist in the indexed sources?",
    "Which documents support the current strategy?",
    "Create a briefing with citations for leadership.",
]

SAVED_PROMPTS = [
    "Executive brief",
    "Risk scan",
    "Technical explainer",
    "Evidence table",
]

DEMO_GRAPH = {
    "nodes": [
        {"id": "Strategy", "label": "Strategy", "type": "concept"},
        {"id": "Customers", "label": "Customers", "type": "entity"},
        {"id": "Revenue", "label": "Revenue", "type": "metric"},
        {"id": "Churn", "label": "Churn", "type": "risk"},
        {"id": "Roadmap", "label": "Roadmap", "type": "concept"},
        {"id": "Support", "label": "Support", "type": "entity"},
    ],
    "edges": [
        {"source": "Strategy", "target": "Revenue", "label": "influences", "weight": 5},
        {"source": "Customers", "target": "Churn", "label": "signals", "weight": 4},
        {"source": "Roadmap", "target": "Customers", "label": "targets", "weight": 3},
        {"source": "Support", "target": "Churn", "label": "reduces", "weight": 2},
        {"source": "Revenue", "target": "Customers", "label": "depends_on", "weight": 3},
    ],
}
