import streamlit as st

from frontend.app.api_client import ApiClient
from frontend.app.components import floating_action, skeleton_grid, topbar
from frontend.app.pages import advanced, analytics, ask_ai, dashboard, ingest, knowledge_graph, settings
from frontend.app.styles import app_css


st.set_page_config(
    page_title="Knowledge Intelligence System",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(app_css(), unsafe_allow_html=True)

if "api_base" not in st.session_state:
    st.session_state.api_base = ApiClient.from_env().base_url
if "workspace" not in st.session_state:
    st.session_state.workspace = "Personal Intelligence"

client = ApiClient(st.session_state.api_base)
connected = False
stats = {
    "total_documents": 0,
    "chunks_indexed": 0,
    "graph_nodes": 0,
    "graph_edges": 0,
    "api_status": "offline",
    "recent_activity": [],
}

try:
    client.health()
    stats = client.stats()
    connected = True
except Exception:
    pass

with st.sidebar:
    st.markdown("### Knowledge OS")
    st.session_state.workspace = st.selectbox(
        "Workspace",
        ["Personal Intelligence", "Research Lab", "Customer Signals", "Leadership Briefing"],
    )
    page = st.radio(
        "Navigation",
        ["Dashboard", "Ingest", "Ask AI", "Knowledge Graph", "Analytics", "Settings", "Advanced"],
        label_visibility="collapsed",
    )
    st.divider()
    command = st.text_input("Command palette", placeholder="Ctrl K: search actions")
    if command:
        st.info(f"Command queued: {command}")
    st.caption("Shortcuts: Ctrl K, / ask, G graph")
    st.divider()
    st.caption("Vector DB")
    st.progress(0.86 if connected else 0.18, text="Healthy" if connected else "Waiting for API")
    st.caption("LLM")
    st.progress(0.72 if connected else 0.12, text="Claude-ready" if connected else "Offline")

topbar(page, stats.get("api_status", "online" if connected else "offline"))

if not connected:
    st.warning("Backend API is offline. The interface is showing demo-ready surfaces until the API is running.")
    skeleton_grid(4)

if page == "Dashboard":
    dashboard(client, stats, connected)
elif page == "Ingest":
    ingest(client)
elif page == "Ask AI":
    ask_ai(client)
elif page == "Knowledge Graph":
    knowledge_graph(client)
elif page == "Analytics":
    analytics()
elif page == "Settings":
    updated_base = settings(client, connected)
    if updated_base and updated_base != st.session_state.api_base:
        st.session_state.api_base = updated_base
        st.rerun()
else:
    advanced()

floating_action("New intelligence task")
