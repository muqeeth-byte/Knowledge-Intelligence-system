import os
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class ApiClient:
    base_url: str

    @classmethod
    def from_env(cls) -> "ApiClient":
        return cls(os.getenv("KIS_API_BASE", "http://localhost:8000/api").rstrip("/"))

    def health(self) -> dict[str, Any]:
        return self._get("/health", timeout=5)

    def stats(self) -> dict[str, Any]:
        return self._get("/stats", timeout=12)

    def graph(self) -> dict[str, Any]:
        return self._get("/graph", timeout=30)

    def ingest_url(self, url: str) -> dict[str, Any]:
        return self._post_json("/ingest/url", {"url": url}, timeout=90)

    def ingest_api(self, endpoint: str, json_path: str | None, title: str | None) -> dict[str, Any]:
        return self._post_json(
            "/ingest/api",
            {"endpoint": endpoint, "json_path": json_path, "title": title},
            timeout=90,
        )

    def ingest_note(self, title: str, text: str, tags: list[str]) -> dict[str, Any]:
        return self._post_json("/ingest/note", {"title": title, "text": text, "tags": tags}, timeout=90)

    def ingest_pdf(self, name: str, data: bytes) -> dict[str, Any]:
        with httpx.Client(timeout=180) as client:
            response = client.post(
                f"{self.base_url}/ingest/pdf",
                files={"file": (name, data, "application/pdf")},
            )
            response.raise_for_status()
            return response.json()

    def query(self, question: str, top_k: int) -> dict[str, Any]:
        return self._post_json("/query", {"question": question, "top_k": top_k}, timeout=120)

    def _get(self, path: str, timeout: int) -> dict[str, Any]:
        with httpx.Client(timeout=timeout) as client:
            response = client.get(f"{self.base_url}{path}")
            response.raise_for_status()
            return response.json()

    def _post_json(self, path: str, payload: dict[str, Any], timeout: int) -> dict[str, Any]:
        with httpx.Client(timeout=timeout) as client:
            response = client.post(f"{self.base_url}{path}", json=payload)
            response.raise_for_status()
            return response.json()
