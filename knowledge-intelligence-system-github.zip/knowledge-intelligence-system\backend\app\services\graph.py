import re
from collections import Counter

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.models import GraphEdge

STOPWORDS = {
    "about",
    "after",
    "also",
    "because",
    "between",
    "from",
    "have",
    "into",
    "more",
    "that",
    "their",
    "there",
    "these",
    "this",
    "with",
    "would",
}


def extract_terms(text: str, limit: int = 8) -> list[str]:
    candidates = re.findall(r"\b[A-Z][A-Za-z0-9&-]{2,}(?:\s+[A-Z][A-Za-z0-9&-]{2,}){0,3}\b", text)
    if not candidates:
        candidates = re.findall(r"\b[a-zA-Z][a-zA-Z0-9&-]{4,}\b", text)
    counts = Counter(candidate.strip() for candidate in candidates if candidate.lower() not in STOPWORDS)
    return [term for term, _ in counts.most_common(limit)]


def update_graph(db: Session, source_id: str, chunk_texts: list[str]) -> None:
    for text in chunk_texts:
        terms = extract_terms(text, limit=6)
        for source_node, target_node in zip(terms, terms[1:]):
            existing = db.scalar(
                select(GraphEdge).where(
                    GraphEdge.source_node == source_node,
                    GraphEdge.target_node == target_node,
                    GraphEdge.relation == "co_occurs_with",
                )
            )
            if existing:
                existing.weight += 1.0
            else:
                db.add(
                    GraphEdge(
                        source_node=source_node,
                        target_node=target_node,
                        relation="co_occurs_with",
                        weight=1.0,
                        source_id=source_id,
                    )
                )


def serialize_graph(db: Session, limit: int = 200) -> dict[str, list[dict]]:
    edges = db.scalars(select(GraphEdge).order_by(GraphEdge.weight.desc()).limit(limit)).all()
    nodes: dict[str, dict] = {}
    serialized_edges = []
    for edge in edges:
        nodes.setdefault(edge.source_node, {"id": edge.source_node, "label": edge.source_node})
        nodes.setdefault(edge.target_node, {"id": edge.target_node, "label": edge.target_node})
        serialized_edges.append(
            {
                "source": edge.source_node,
                "target": edge.target_node,
                "label": edge.relation,
                "weight": edge.weight,
            }
        )
    return {"nodes": list(nodes.values()), "edges": serialized_edges}
