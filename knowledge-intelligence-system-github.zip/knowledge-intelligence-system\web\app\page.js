"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  Bot,
  Braces,
  ChevronRight,
  Clipboard,
  Code2,
  Database,
  Download,
  FileUp,
  Filter,
  Globe2,
  KeyRound,
  Link2,
  Loader2,
  MessageSquareText,
  Send,
  SlidersHorizontal,
  Sparkles,
  Tags,
  UploadCloud
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

import { ActivityFeed, MetricCard, SectionTitle } from "@/components/Cards";
import { CommandPalette } from "@/components/CommandPalette";
import { GraphCanvas } from "@/components/GraphCanvas";
import { Sidebar } from "@/components/Sidebar";
import { Topbar } from "@/components/Topbar";
import { api } from "@/lib/api";
import { analyticsSeries, demoGraph, demoStats, suggestions } from "@/lib/demo-data";

const titles = {
  dashboard: "Dashboard",
  ingest: "Knowledge Ingestion",
  ask: "Ask AI",
  graph: "Knowledge Graph",
  analytics: "Analytics",
  settings: "Settings",
  advanced: "Advanced"
};

export default function Home() {
  const [active, setActive] = useState("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [connected, setConnected] = useState(false);
  const [stats, setStats] = useState(demoStats);
  const [graph, setGraph] = useState(demoGraph);

  const refreshBackend = useCallback(async () => {
    try {
      await api.health();
      const [statsResult, graphResult] = await Promise.all([api.stats(), api.graph()]);
      setStats(statsResult.recent_activity?.length ? statsResult : { ...statsResult, recent_activity: demoStats.recent_activity });
      setGraph(graphResult.nodes?.length ? graphResult : demoGraph);
      setConnected(true);
    } catch {
      setConnected(false);
      setStats(demoStats);
      setGraph(demoGraph);
    }
  }, []);

  useEffect(() => {
    refreshBackend();
  }, [refreshBackend]);

  useEffect(() => {
    const handleKey = (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen(true);
      }
      if (event.key === "/" && active !== "ask") {
        event.preventDefault();
        setActive("ask");
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [active]);

  return (
    <main className="appShell">
      <Sidebar
        active={active}
        collapsed={collapsed}
        connected={connected}
        onChange={setActive}
        onToggle={() => setCollapsed((value) => !value)}
      />
      <section className="workspace">
        <Topbar title={titles[active]} connected={connected} onCommand={() => setPaletteOpen(true)} />
        {active === "dashboard" && <Dashboard stats={stats} connected={connected} onNavigate={setActive} />}
        {active === "ingest" && <Ingest onRefresh={refreshBackend} />}
        {active === "ask" && <AskAI />}
        {active === "graph" && <KnowledgeGraph graph={graph} />}
        {active === "analytics" && <Analytics />}
        {active === "settings" && <Settings connected={connected} onRefresh={refreshBackend} />}
        {active === "advanced" && <Advanced />}
      </section>
      <button className="floatingAction" onClick={() => setPaletteOpen(true)}>
        <Sparkles size={18} />
        New intelligence task
      </button>
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onNavigate={setActive} />
    </main>
  );
}

function Dashboard({ stats, connected, onNavigate }) {
  return (
    <div className="pageStack">
      <section className="heroBand">
        <div>
          <span className="eyebrow">AI knowledge command center</span>
          <h2>Turn scattered PDFs, URLs, APIs, and notes into cited intelligence.</h2>
          <p>
            Semantic retrieval, Claude reasoning, confidence scoring, and graph exploration in one premium interface.
          </p>
        </div>
        <div className="heroActions">
          <button onClick={() => onNavigate("ingest")}>
            <UploadCloud size={18} />
            Ingest sources
          </button>
          <button onClick={() => onNavigate("ask")}>
            <MessageSquareText size={18} />
            Ask AI
          </button>
        </div>
      </section>

      <section className="metricGrid">
        <MetricCard label="Total documents" value={stats.total_documents} detail="Indexed source records" icon="documents" />
        <MetricCard label="Chunks indexed" value={stats.chunks_indexed} detail="Semantic retrieval units" icon="chunks" />
        <MetricCard label="Graph nodes" value={stats.graph_nodes} detail={`${stats.graph_edges || 0} relationships`} icon="graph" />
        <MetricCard label="API status" value={connected ? "Online" : "Demo"} detail={api.baseUrl} icon="status" />
      </section>

      <section className="twoColumn">
        <div className="glass">
          <SectionTitle eyebrow="Analytics" title="Knowledge activity" />
          <Chart />
        </div>
        <div className="glass">
          <SectionTitle eyebrow="Activity" title="Recent events" />
          <ActivityFeed items={stats.recent_activity || []} />
        </div>
      </section>
    </div>
  );
}

function Ingest({ onRefresh }) {
  const [tab, setTab] = useState("pdf");
  const [tags, setTags] = useState("Research, Strategy");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  async function run(action) {
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const output = await action();
      setResult(output);
      onRefresh();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="pageStack">
      <SectionTitle eyebrow="Ingestion" title="Add knowledge from every source" />
      <div className="ingestTabs">
        {[
          ["pdf", FileUp, "Upload PDF"],
          ["url", Globe2, "Website URL"],
          ["api", Braces, "API endpoint"],
          ["notes", Clipboard, "Manual notes"]
        ].map(([id, Icon, label]) => (
          <button className={tab === id ? "active" : ""} key={id} onClick={() => setTab(id)}>
            <Icon size={17} />
            {label}
          </button>
        ))}
      </div>

      <div className="twoColumn wideLeft">
        <div className="glass formPanel">
          <TagInput value={tags} onChange={setTags} />
          {tab === "pdf" && <PdfForm loading={loading} onRun={run} />}
          {tab === "url" && <UrlForm loading={loading} onRun={run} />}
          {tab === "api" && <ApiForm loading={loading} onRun={run} />}
          {tab === "notes" && <NoteForm loading={loading} onRun={run} tags={tags} />}
          {error && <div className="errorState">{error}</div>}
          {result && <div className="successState">Indexed {result.chunks} chunks into the knowledge base.</div>}
        </div>
        <div className="glass pipelinePanel">
          <SectionTitle eyebrow="Pipeline" title="Realtime processing states" />
          {["Extract metadata", "Normalize text", "Chunk with overlap", "Generate embeddings", "Upsert vectors", "Track citations"].map((step, index) => (
            <div className="pipelineStep" key={step}>
              <span>{index + 1}</span>
              <strong>{step}</strong>
              <small>{loading && index < 4 ? "running" : "ready"}</small>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PdfForm({ loading, onRun }) {
  const [files, setFiles] = useState([]);
  return (
    <div className="formStack">
      <label className="dropzone">
        <FileUp size={30} />
        <strong>Drag and drop PDF files</strong>
        <span>Multi-file upload with metadata preview and progress states</span>
        <input multiple type="file" accept="application/pdf" onChange={(event) => setFiles([...event.target.files])} />
      </label>
      {files.length > 0 && (
        <div className="fileList">
          {files.map((file) => (
            <div key={file.name}>
              <span>{file.name}</span>
              <small>{Math.round(file.size / 1024)} KB</small>
            </div>
          ))}
        </div>
      )}
      <button disabled={!files.length || loading} onClick={() => onRun(() => api.ingestPdf(files[0]))}>
        {loading ? <Loader2 className="spin" size={17} /> : <Sparkles size={17} />}
        Generate embeddings
      </button>
    </div>
  );
}

function UrlForm({ loading, onRun }) {
  const [url, setUrl] = useState("");
  return (
    <div className="formStack">
      <label>
        Website URL
        <input value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://example.com/research" />
      </label>
      <label>
        Crawl depth
        <input type="range" min="1" max="5" defaultValue="1" />
      </label>
      <button disabled={!url || loading} onClick={() => onRun(() => api.ingestUrl(url))}>
        {loading ? <Loader2 className="spin" size={17} /> : <Link2 size={17} />}
        Ingest website
      </button>
    </div>
  );
}

function ApiForm({ loading, onRun }) {
  const [endpoint, setEndpoint] = useState("");
  const [jsonPath, setJsonPath] = useState("");
  const [title, setTitle] = useState("");
  return (
    <div className="formStack">
      <label>
        Endpoint
        <input value={endpoint} onChange={(event) => setEndpoint(event.target.value)} placeholder="https://api.example.com/items" />
      </label>
      <label>
        JSON path
        <input value={jsonPath} onChange={(event) => setJsonPath(event.target.value)} placeholder="Optional: data.0.body" />
      </label>
      <label>
        Source title
        <input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Optional display name" />
      </label>
      <button disabled={!endpoint || loading} onClick={() => onRun(() => api.ingestApi(endpoint, jsonPath, title))}>
        {loading ? <Loader2 className="spin" size={17} /> : <Code2 size={17} />}
        Connect API
      </button>
    </div>
  );
}

function NoteForm({ loading, onRun, tags }) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  return (
    <div className="formStack">
      <label>
        Note title
        <input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Board meeting notes" />
      </label>
      <label>
        Knowledge note
        <textarea value={text} onChange={(event) => setText(event.target.value)} placeholder="Paste notes, transcripts, research snippets, or decisions." />
      </label>
      <button disabled={!title || !text || loading} onClick={() => onRun(() => api.ingestNote(title, text, splitTags(tags)))}>
        {loading ? <Loader2 className="spin" size={17} /> : <Tags size={17} />}
        Save note to memory
      </button>
    </div>
  );
}

function TagInput({ value, onChange }) {
  return (
    <label className="tagInput">
      Source tags
      <input value={value} onChange={(event) => onChange(event.target.value)} />
      <span>{splitTags(value).map((tag) => <em key={tag}>{tag}</em>)}</span>
    </label>
  );
}

function AskAI() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Ask a question across your indexed knowledge. I will answer with citations and confidence." }
  ]);
  const [question, setQuestion] = useState("");
  const [depth, setDepth] = useState(6);
  const [loading, setLoading] = useState(false);

  async function ask(prompt = question) {
    if (!prompt.trim()) return;
    setMessages((items) => [...items, { role: "user", content: prompt }]);
    setQuestion("");
    setLoading(true);
    try {
      const result = await api.query(prompt, depth);
      setMessages((items) => [
        ...items,
        { role: "assistant", content: result.answer, citations: result.citations, confidence: result.confidence }
      ]);
    } catch {
      setMessages((items) => [
        ...items,
        {
          role: "assistant",
          content:
            "Demo response: connect a public FastAPI backend in NEXT_PUBLIC_API_BASE_URL to enable live Claude reasoning, semantic retrieval, and citations.",
          confidence: 0.72,
          citations: []
        }
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="askLayout">
      <section className="chatPanel glass">
        <div className="messages">
          {messages.map((message, index) => (
            <div className={`message ${message.role}`} key={index}>
              <span>{message.role === "assistant" ? <Bot size={17} /> : <MessageSquareText size={17} />}</span>
              <div>
                <ReactMarkdown>{message.content}</ReactMarkdown>
                {message.confidence !== undefined && <small>Confidence {message.confidence.toFixed(2)}</small>}
                {message.citations?.length > 0 && (
                  <details>
                    <summary>Evidence panels</summary>
                    {message.citations.map((citation, citationIndex) => (
                      <article key={citation.chunk_id}>
                        <strong>[{citationIndex + 1}] {citation.title || citation.uri}</strong>
                        <small>{citation.uri} · score {citation.score.toFixed(3)}</small>
                        <p>{citation.excerpt}</p>
                      </article>
                    ))}
                  </details>
                )}
              </div>
            </div>
          ))}
          {loading && <div className="typing"><Loader2 className="spin" size={16} /> Reasoning over retrieved evidence...</div>}
        </div>
        <div className="composer">
          <textarea value={question} onChange={(event) => setQuestion(event.target.value)} placeholder="Ask a cited question..." />
          <button onClick={() => ask()} disabled={loading || !question.trim()}>
            <Send size={18} />
          </button>
        </div>
      </section>
      <aside className="glass controlPanel">
        <SectionTitle eyebrow="Retrieval" title="Controls" />
        <label>
          Evidence depth: {depth}
          <input type="range" min="3" max="12" value={depth} onChange={(event) => setDepth(Number(event.target.value))} />
        </label>
        <label>
          Semantic filters
          <select>
            <option>All sources</option>
            <option>PDF only</option>
            <option>URLs only</option>
            <option>High confidence</option>
          </select>
        </label>
        <SectionTitle eyebrow="Prompts" title="Follow-ups" />
        {suggestions.map((item) => (
          <button className="ghostButton" key={item} onClick={() => ask(item)}>{item}</button>
        ))}
        <button className="downloadButton">
          <Download size={16} />
          Export conversation
        </button>
      </aside>
    </div>
  );
}

function KnowledgeGraph({ graph }) {
  return (
    <div className="pageStack">
      <SectionTitle
        eyebrow="Graph"
        title="Interactive relationship map"
        action={<button className="ghostButton"><Filter size={16} /> Filter</button>}
      />
      <GraphCanvas graph={graph} />
    </div>
  );
}

function Analytics() {
  return (
    <div className="pageStack">
      <section className="metricGrid">
        <MetricCard label="Answer confidence" value="0.82" detail="Trailing answer quality" icon="status" />
        <MetricCard label="Citation coverage" value="94%" detail="Answers with evidence" icon="chunks" />
        <MetricCard label="Hybrid recall" value="Ready" detail="Keyword + vector roadmap" icon="graph" />
        <MetricCard label="Latency p95" value="1.8s" detail="Demo response metric" icon="documents" />
      </section>
      <div className="glass">
        <SectionTitle eyebrow="Analytics" title="Retrieval and ingestion velocity" />
        <Chart />
      </div>
    </div>
  );
}

function Settings({ connected, onRefresh }) {
  return (
    <div className="settingsGrid">
      <div className="glass formPanel">
        <SectionTitle eyebrow="Backend" title="System settings" />
        <label>
          API base URL
          <input readOnly value={api.baseUrl} />
        </label>
        <label>
          LLM provider
          <select defaultValue="Claude">
            <option>Claude</option>
            <option>OpenAI</option>
            <option>Local</option>
          </select>
        </label>
        <label>
          Embedding model
          <select defaultValue="text-embedding-3-small">
            <option>text-embedding-3-small</option>
            <option>text-embedding-3-large</option>
            <option>local-hash</option>
          </select>
        </label>
        <button onClick={onRefresh}>
          <SlidersHorizontal size={17} />
          Run diagnostics
        </button>
      </div>
      <div className="glass">
        <SectionTitle eyebrow="Diagnostics" title="Runtime state" />
        <pre>{JSON.stringify({ apiBase: api.baseUrl, connected, vercelReady: true }, null, 2)}</pre>
        <div className="logConsole">
          INFO Next.js interface ready{"\n"}
          INFO Vercel deployment compatible{"\n"}
          INFO FastAPI backend configured through NEXT_PUBLIC_API_BASE_URL{"\n"}
          WARN Localhost API is not reachable from public Vercel deployments
        </div>
      </div>
    </div>
  );
}

function Advanced() {
  const modules = [
    ["Multi-workspace", "Isolated retrieval scopes and knowledge domains."],
    ["Team collaboration", "Shared reviews, comments, and activity attribution."],
    ["Role-based access", "Admin, analyst, viewer, and auditor modes."],
    ["Saved prompts", "Reusable brief, risk, and evidence workflows."],
    ["AI agents", "Autonomous research, summarization, and contradiction checks."],
    ["Memory layer", "Persistent preferences and conversation memory."],
    ["Knowledge timelines", "Time-aware source evolution and claim tracking."],
    ["Hybrid search", "Keyword scoring blended with vector similarity."]
  ];
  return (
    <div className="moduleGrid">
      {modules.map(([title, body]) => (
        <article className="glass moduleCard" key={title}>
          <KeyRound size={18} />
          <h3>{title}</h3>
          <p>{body}</p>
          <ChevronRight size={17} />
        </article>
      ))}
    </div>
  );
}

function Chart() {
  return (
    <div className="chartWrap">
      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={analyticsSeries}>
          <defs>
            <linearGradient id="documents" x1="0" x2="0" y1="0" y2="1">
              <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.45} />
              <stop offset="95%" stopColor="#22d3ee" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="queries" x1="0" x2="0" y1="0" y2="1">
              <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.38} />
              <stop offset="95%" stopColor="#60a5fa" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="rgba(148, 163, 184, 0.12)" vertical={false} />
          <XAxis dataKey="day" stroke="#94a3b8" tickLine={false} axisLine={false} />
          <YAxis stroke="#94a3b8" tickLine={false} axisLine={false} />
          <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid rgba(148,163,184,.22)", borderRadius: 12 }} />
          <Area dataKey="documents" stroke="#22d3ee" fill="url(#documents)" strokeWidth={2} />
          <Area dataKey="queries" stroke="#60a5fa" fill="url(#queries)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function splitTags(value) {
  return value.split(",").map((tag) => tag.trim()).filter(Boolean);
}
