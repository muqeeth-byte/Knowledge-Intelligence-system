from collections.abc import Iterable
from datetime import datetime
from typing import Any

import pandas as pd
import streamlit as st


def topbar(page_title: str, api_status: str) -> None:
    status_label = "Online" if api_status == "online" else "Offline"
    st.markdown(
        f"""
        <div class="topbar">
          <div class="brand">
            <div class="brand-mark">KI</div>
            <div>
              <div>{page_title}</div>
              <div class="metric-label">Knowledge Intelligence System</div>
            </div>
          </div>
          <div class="command-pill">Command palette <strong>Ctrl K</strong></div>
          <div class="metric-label"><span class="status-dot"></span>{status_label}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def metric_card(label: str, value: str | int, detail: str, tone: str = "blue") -> None:
    st.markdown(
        f"""
        <div class="glass-card">
          <div class="metric-label">{label}</div>
          <div class="metric-value">{value}</div>
          <div class="muted">{detail}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def glass_panel(title: str, subtitle: str | None = None) -> None:
    subtitle_html = f'<div class="muted">{subtitle}</div>' if subtitle else ""
    st.markdown(f'<div class="section-title"><div><h2>{title}</h2>{subtitle_html}</div></div>', unsafe_allow_html=True)


def tags(items: Iterable[str]) -> None:
    html = "".join(f'<span class="tag">{item}</span>' for item in items if item)
    st.markdown(html, unsafe_allow_html=True)


def activity_feed(items: list[dict[str, Any]]) -> None:
    if not items:
        empty_state("No activity yet", "Ingest your first source to populate the activity stream.")
        return
    for item in items[:8]:
        timestamp = format_timestamp(item.get("timestamp", ""))
        st.markdown(
            f"""
            <div class="glass-card" style="padding:0.82rem;margin-bottom:0.55rem;">
              <div style="display:flex;justify-content:space-between;gap:1rem;">
                <strong>{item.get("type", "Activity")}</strong>
                <span class="muted">{timestamp}</span>
              </div>
              <div class="muted" style="margin-top:0.25rem;">{item.get("title", "Untitled")}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def analytics_chart(rows: list[dict[str, Any]]) -> None:
    data = pd.DataFrame(rows)
    st.area_chart(data.set_index("day"), height=280)


def empty_state(title: str, body: str) -> None:
    st.markdown(
        f"""
        <div class="empty-state">
          <div style="font-size:2.2rem;line-height:1;">◇</div>
          <h3>{title}</h3>
          <div class="muted">{body}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def skeleton_grid(count: int = 4) -> None:
    cols = st.columns(count)
    for col in cols:
        with col:
            st.markdown('<div class="skeleton"></div>', unsafe_allow_html=True)


def floating_action(label: str) -> None:
    st.markdown(f'<div class="floating-action">{label}</div>', unsafe_allow_html=True)


def format_timestamp(value: str) -> str:
    if not value or value == "demo":
        return "demo"
    try:
        return datetime.fromisoformat(value).strftime("%b %d, %H:%M")
    except ValueError:
        return value
