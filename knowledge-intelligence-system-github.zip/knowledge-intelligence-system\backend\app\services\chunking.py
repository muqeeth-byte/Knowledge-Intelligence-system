import re


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 180) -> list[str]:
    clean = normalize_text(text)
    if not clean:
        return []

    chunks: list[str] = []
    start = 0
    while start < len(clean):
        end = min(start + chunk_size, len(clean))
        if end < len(clean):
            sentence_end = max(clean.rfind(". ", start, end), clean.rfind("? ", start, end), clean.rfind("! ", start, end))
            if sentence_end > start + chunk_size // 2:
                end = sentence_end + 1
        chunks.append(clean[start:end].strip())
        if end == len(clean):
            break
        start = max(0, end - overlap)
    return [chunk for chunk in chunks if chunk]


def estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)
