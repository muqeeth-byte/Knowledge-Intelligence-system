from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models import Chunk, Document, GraphEdge, QueryLog, Source
from backend.app.schemas import (
    ApiIngestRequest,
    DashboardStats,
    GraphResponse,
    IngestResponse,
    ManualNoteIngestRequest,
    QueryRequest,
    QueryResponse,
    UrlIngestRequest,
)
from backend.app.services.extractors import extract_api, extract_pdf, extract_url
from backend.app.services.graph import serialize_graph
from backend.app.services.ingestion import IngestionService
from backend.app.services.qa import QAService
from backend.app.api.dependencies import get_ingestion_service, get_qa_service

router = APIRouter()


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/stats", response_model=DashboardStats)
def stats(db: Session = Depends(get_db)) -> DashboardStats:
    total_documents = db.scalar(select(func.count(Document.id))) or 0
    chunks_indexed = db.scalar(select(func.count(Chunk.id))) or 0
    graph_edges = db.scalar(select(func.count(GraphEdge.id))) or 0
    edge_rows = db.execute(select(GraphEdge.source_node, GraphEdge.target_node)).all()
    graph_nodes = len({node for row in edge_rows for node in row if node})

    sources = db.scalars(select(Source).order_by(Source.created_at.desc()).limit(6)).all()
    queries = db.scalars(select(QueryLog).order_by(QueryLog.created_at.desc()).limit(4)).all()
    recent_activity = [
        {
            "type": f"{source.kind} ingested",
            "title": source.title or source.uri,
            "timestamp": source.created_at.isoformat(),
        }
        for source in sources
    ]
    recent_activity.extend(
        {
            "type": "AI answer",
            "title": query.question[:90],
            "timestamp": query.created_at.isoformat(),
        }
        for query in queries
    )
    recent_activity = sorted(recent_activity, key=lambda item: item["timestamp"], reverse=True)[:8]
    return DashboardStats(
        total_documents=total_documents,
        chunks_indexed=chunks_indexed,
        graph_nodes=graph_nodes,
        graph_edges=graph_edges,
        api_status="online",
        recent_activity=recent_activity,
    )


@router.post("/ingest/pdf", response_model=IngestResponse)
async def ingest_pdf(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    ingestion: IngestionService = Depends(get_ingestion_service),
) -> IngestResponse:
    if file.content_type not in {"application/pdf", "application/octet-stream"}:
        raise HTTPException(status_code=400, detail="Upload a PDF file.")
    content = await file.read()
    text = extract_pdf(content)
    if not text.strip():
        raise HTTPException(status_code=422, detail="No extractable text found in PDF.")
    result = ingestion.ingest_text(db, kind="pdf", uri=file.filename or "uploaded.pdf", title=file.filename, text=text)
    return IngestResponse(source_id=result.source_id, document_id=result.document_id, chunks=result.chunks)


@router.post("/ingest/url", response_model=IngestResponse)
async def ingest_url(
    request: UrlIngestRequest,
    db: Session = Depends(get_db),
    ingestion: IngestionService = Depends(get_ingestion_service),
) -> IngestResponse:
    title, text = await extract_url(str(request.url))
    if not text.strip():
        raise HTTPException(status_code=422, detail="No readable text found at URL.")
    result = ingestion.ingest_text(db, kind="url", uri=str(request.url), title=title, text=text)
    return IngestResponse(source_id=result.source_id, document_id=result.document_id, chunks=result.chunks)


@router.post("/ingest/api", response_model=IngestResponse)
async def ingest_api(
    request: ApiIngestRequest,
    db: Session = Depends(get_db),
    ingestion: IngestionService = Depends(get_ingestion_service),
) -> IngestResponse:
    text = await extract_api(str(request.endpoint), request.json_path)
    if not text.strip():
        raise HTTPException(status_code=422, detail="No readable text found in API response.")
    result = ingestion.ingest_text(db, kind="api", uri=str(request.endpoint), title=request.title, text=text)
    return IngestResponse(source_id=result.source_id, document_id=result.document_id, chunks=result.chunks)


@router.post("/ingest/note", response_model=IngestResponse)
def ingest_note(
    request: ManualNoteIngestRequest,
    db: Session = Depends(get_db),
    ingestion: IngestionService = Depends(get_ingestion_service),
) -> IngestResponse:
    text = request.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="Note text is required.")
    tag_suffix = f"\n\nTags: {', '.join(request.tags)}" if request.tags else ""
    result = ingestion.ingest_text(
        db,
        kind="note",
        uri=f"note://{request.title}",
        title=request.title,
        text=f"{text}{tag_suffix}",
    )
    return IngestResponse(source_id=result.source_id, document_id=result.document_id, chunks=result.chunks)


@router.post("/query", response_model=QueryResponse)
def query(
    request: QueryRequest,
    db: Session = Depends(get_db),
    qa: QAService = Depends(get_qa_service),
) -> QueryResponse:
    result = qa.answer(db, request.question, top_k=request.top_k)
    return QueryResponse(**result)


@router.get("/graph", response_model=GraphResponse)
def graph(db: Session = Depends(get_db)) -> GraphResponse:
    return GraphResponse(**serialize_graph(db))
