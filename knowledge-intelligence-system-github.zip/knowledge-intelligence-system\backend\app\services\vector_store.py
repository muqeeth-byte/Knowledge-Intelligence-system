import math
from dataclasses import dataclass
from typing import Any

from pinecone import Pinecone, ServerlessSpec

from backend.app.config import Settings


@dataclass
class VectorMatch:
    id: str
    score: float
    metadata: dict[str, Any]


class VectorStore:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._memory: dict[str, tuple[list[float], dict[str, Any]]] = {}
        self.index = None
        if settings.pinecone_api_key:
            pc = Pinecone(api_key=settings.pinecone_api_key)
            existing = set(pc.list_indexes().names())
            if settings.pinecone_index not in existing:
                pc.create_index(
                    name=settings.pinecone_index,
                    dimension=settings.embedding_dimension,
                    metric="cosine",
                    spec=ServerlessSpec(cloud=settings.pinecone_cloud, region=settings.pinecone_region),
                )
            self.index = pc.Index(settings.pinecone_index)

    def upsert(self, vectors: list[tuple[str, list[float], dict[str, Any]]]) -> None:
        if self.index:
            self.index.upsert(vectors=[{"id": id_, "values": values, "metadata": metadata} for id_, values, metadata in vectors])
            return
        for id_, values, metadata in vectors:
            self._memory[id_] = (values, metadata)

    def query(self, vector: list[float], top_k: int) -> list[VectorMatch]:
        if self.index:
            result = self.index.query(vector=vector, top_k=top_k, include_metadata=True)
            matches = result.matches if hasattr(result, "matches") else result.get("matches", [])
            return [VectorMatch(id=item["id"], score=float(item["score"]), metadata=item.get("metadata", {})) for item in matches]

        scored = [
            VectorMatch(id=id_, score=_cosine(vector, values), metadata=metadata)
            for id_, (values, metadata) in self._memory.items()
        ]
        return sorted(scored, key=lambda match: match.score, reverse=True)[:top_k]


def _cosine(a: list[float], b: list[float]) -> float:
    numerator = sum(x * y for x, y in zip(a, b))
    left = math.sqrt(sum(x * x for x in a)) or 1.0
    right = math.sqrt(sum(y * y for y in b)) or 1.0
    return numerator / (left * right)
