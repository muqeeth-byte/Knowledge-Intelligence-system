from functools import lru_cache

from backend.app.config import get_settings
from backend.app.services.embeddings import EmbeddingService
from backend.app.services.ingestion import IngestionService
from backend.app.services.qa import QAService
from backend.app.services.vector_store import VectorStore


@lru_cache
def get_embedding_service() -> EmbeddingService:
    return EmbeddingService(get_settings())


@lru_cache
def get_vector_store() -> VectorStore:
    return VectorStore(get_settings())


def get_ingestion_service() -> IngestionService:
    return IngestionService(get_embedding_service(), get_vector_store())


def get_qa_service() -> QAService:
    return QAService(get_settings(), get_embedding_service(), get_vector_store())
