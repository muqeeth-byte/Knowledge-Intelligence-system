from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Knowledge Intelligence System"
    environment: str = "development"
    database_url: str = "postgresql+psycopg://kis:kis@localhost:5432/kis"

    pinecone_api_key: str | None = None
    pinecone_index: str = "knowledge-intelligence"
    pinecone_cloud: str = "aws"
    pinecone_region: str = "us-east-1"

    openai_api_key: str | None = None
    embedding_model: str = "text-embedding-3-small"
    embedding_dimension: int = 1536

    anthropic_api_key: str | None = None
    claude_model: str = "claude-3-5-sonnet-latest"

    backend_cors_origins: str = Field(default="http://localhost:8501,http://127.0.0.1:8501")

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.backend_cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
