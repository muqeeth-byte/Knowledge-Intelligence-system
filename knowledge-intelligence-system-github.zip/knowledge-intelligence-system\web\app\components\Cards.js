import { ArrowUpRight, CheckCircle2, Clock3, FileText, Network, ShieldCheck } from "lucide-react";

const iconMap = {
  documents: FileText,
  chunks: CheckCircle2,
  graph: Network,
  status: ShieldCheck
};

export function MetricCard({ label, value, detail, icon = "documents" }) {
  const Icon = iconMap[icon] || FileText;
  return (
    <article className="glass metricCard">
      <div className="metricIcon">
        <Icon size={19} />
      </div>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}

export function ActivityFeed({ items }) {
  return (
    <div className="activityList">
      {items.map((item, index) => (
        <div className="activityItem" key={`${item.title}-${index}`}>
          <div>
            <Clock3 size={15} />
          </div>
          <span>
            <strong>{item.type}</strong>
            <small>{item.title}</small>
          </span>
          <ArrowUpRight size={15} />
        </div>
      ))}
    </div>
  );
}

export function SectionTitle({ eyebrow, title, action }) {
  return (
    <div className="sectionTitle">
      <div>
        <span>{eyebrow}</span>
        <h2>{title}</h2>
      </div>
      {action}
    </div>
  );
}
