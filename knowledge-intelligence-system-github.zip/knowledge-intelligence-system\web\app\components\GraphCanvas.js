"use client";

import { useMemo, useState } from "react";

const colors = {
  concept: "#22d3ee",
  entity: "#60a5fa",
  metric: "#34d399",
  risk: "#fb7185",
  default: "#a78bfa"
};

function inferType(label = "") {
  const lowered = label.toLowerCase();
  if (["risk", "churn", "issue"].some((word) => lowered.includes(word))) return "risk";
  if (["revenue", "score", "rate", "cost"].some((word) => lowered.includes(word))) return "metric";
  if (["customer", "user", "team", "company"].some((word) => lowered.includes(word))) return "entity";
  return "concept";
}

export function GraphCanvas({ graph }) {
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState("");
  const nodes = useMemo(() => {
    const source = graph.nodes || [];
    return source.slice(0, 90).map((node, index) => {
      const angle = (Math.PI * 2 * index) / Math.max(1, source.length);
      const radius = 130 + (index % 5) * 28;
      return {
        ...node,
        type: node.type || inferType(node.label || node.id),
        x: 430 + Math.cos(angle) * radius,
        y: 260 + Math.sin(angle) * (radius * 0.72)
      };
    });
  }, [graph.nodes]);
  const nodeMap = new Map(nodes.map((node) => [node.id, node]));
  const edges = (graph.edges || []).slice(0, 180).filter((edge) => nodeMap.has(edge.source) && nodeMap.has(edge.target));
  const selectedEdges = selected ? edges.filter((edge) => edge.source === selected.id || edge.target === selected.id) : [];

  return (
    <div className="graphPanel glass">
      <div className="graphToolbar">
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search graph nodes" />
        <span>Zoom-ready SVG map · click nodes to inspect relationships</span>
      </div>
      <svg viewBox="0 0 860 540" className="graphSvg">
        <defs>
          <radialGradient id="nodeGlow">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.72" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>
        {edges.map((edge, index) => {
          const source = nodeMap.get(edge.source);
          const target = nodeMap.get(edge.target);
          const hot = selected && (edge.source === selected.id || edge.target === selected.id);
          return (
            <line
              className={hot ? "hotEdge" : "edge"}
              key={`${edge.source}-${edge.target}-${index}`}
              x1={source.x}
              y1={source.y}
              x2={target.x}
              y2={target.y}
            />
          );
        })}
        {nodes.map((node) => {
          const muted = query && !(node.label || node.id).toLowerCase().includes(query.toLowerCase());
          return (
            <g
              className={`graphNode ${muted ? "mutedNode" : ""}`}
              key={node.id}
              onClick={() => setSelected(node)}
            >
              <circle cx={node.x} cy={node.y} r="18" fill="url(#nodeGlow)" />
              <circle cx={node.x} cy={node.y} r="8" fill={colors[node.type] || colors.default} />
              <text x={node.x + 13} y={node.y + 4}>
                {node.label || node.id}
              </text>
            </g>
          );
        })}
      </svg>
      <aside className="nodeInspector">
        <strong>{selected ? selected.label || selected.id : "Node details"}</strong>
        <p>{selected ? `Type: ${selected.type}` : "Select a node to inspect connected evidence and relationships."}</p>
        <small>{selected ? `${selectedEdges.length} highlighted relationships` : "Physics layout and clustering hooks are ready for a graph engine."}</small>
      </aside>
    </div>
  );
}
