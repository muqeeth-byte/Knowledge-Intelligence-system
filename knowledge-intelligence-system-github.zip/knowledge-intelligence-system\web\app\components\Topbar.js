"use client";

import { Bell, Command, Moon, Plus, Search } from "lucide-react";

export function Topbar({ title, connected, onCommand }) {
  return (
    <header className="topbar">
      <div>
        <div className="breadcrumbs">Workspace / Personal Intelligence / {title}</div>
        <h1>{title}</h1>
      </div>
      <button className="commandButton" onClick={onCommand}>
        <Search size={16} />
        Search knowledge
        <kbd>
          <Command size={12} />K
        </kbd>
      </button>
      <div className="topbarActions">
        <span className={`connection ${connected ? "online" : "demo"}`}>
          <span />
          {connected ? "Online" : "Demo"}
        </span>
        <button aria-label="Dark mode">
          <Moon size={17} />
        </button>
        <button aria-label="Notifications">
          <Bell size={17} />
        </button>
        <button className="primaryAction">
          <Plus size={17} />
          New task
        </button>
      </div>
    </header>
  );
}
