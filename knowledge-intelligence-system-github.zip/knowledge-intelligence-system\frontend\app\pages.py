import time
from typing import Any

import pandas as pd
import streamlit as st
from streamlit.components.v1 import html as component_html

from frontend.app.api_client import ApiClient
from frontend.app.components import activity_feed, analytics_chart, empty_state, glass_panel, metric_card, tags
from frontend.app.demo_data import ANALYTICS_SERIES, DEMO_GRAPH, RECENT_ACTIVITY, SAVED_PROMPTS, SUGGESTED_PROMPTS
from frontend.app.graph_view import render_interactive_graph


def dashboard(client: ApiClient, stats: dict[str, Any], connected: bool) -> None:
    cols = st.columns(4)
    metrics = [
        ("Total documents", stats.get("total_documents", 0), "Indexed source records"),
        ("Chunks indexed", stats.get("chunks_indexed", 0), "Semantic retrieval units"),
        ("Graph nodes", stats.get("graph_nodes", 0), "Detected knowledge entities"),
        ("API status", "Online" if connected else "Offline", client.base_url),
    ]
    for col, metric in zip(cols, metrics):
        with col:
            metric_card(*metric)

    left, right = st.columns([1.65, 1])
    with left:
        glass_panel("Analytics", "Animated retrieval and ingestion trend")
        analytics_chart(ANALYTICS_SERIES)
    with right:
        glass_panel("Recent Activity", "Live backend activity with demo fallback")
        activity_feed(stats.get("recent_activity") or RECENT_ACTIVITY)

    glass_panel("Quick Actions", "Start common intelligence workflows")
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.button("Ingest sources", use_container_width=True)
    with c2:
        st.button("Ask AI", use_container_width=True)
    with c3:
        st.button("Explore graph", use_container_width=True)
    with c4:
        st.button("Run diagnostics", use_container_width=True)


def ingest(client: ApiClient) -> None:
    glass_panel("Knowledge Ingestion", "Upload files, crawl URLs, connect APIs, or capture manual notes")
    source_tags = st.multiselect(
        "Source tags",
        ["Strategy", "Research", "Customer", "Legal", "Engineering", "Finance", "Urgent"],
        default=["Research"],
    )
    tags(source_tags)

    pdf_tab, url_tab, api_tab, note_tab = st.tabs(["Upload PDF", "Website URL", "API endpoint", "Manual notes"])

    with pdf_tab:
        uploaded_files = st.file_uploader("Drag and drop PDF files", type=["pdf"], accept_multiple_files=True)
        if uploaded_files:
            st.markdown("#### Metadata preview")
            preview_rows = [
                {"file": file.name, "size_kb": round(len(file.getvalue()) / 1024, 1), "status": "ready"}
                for file in uploaded_files
            ]
            st.dataframe(pd.DataFrame(preview_rows), use_container_width=True, hide_index=True)
        if st.button("Generate embeddings", disabled=not uploaded_files, use_container_width=True):
            progress = st.progress(0, text="Preparing source metadata")
            for index, file in enumerate(uploaded_files or [], start=1):
                progress.progress((index - 1) / max(1, len(uploaded_files)), text=f"Extracting {file.name}")
                with st.status(f"Indexing {file.name}", expanded=False) as status:
                    result = client.ingest_pdf(file.name, file.getvalue())
                    status.update(label=f"{file.name}: {result['chunks']} chunks indexed", state="complete")
                progress.progress(index / max(1, len(uploaded_files)), text="Embedding complete")
            st.toast("PDF ingestion complete")

    with url_tab:
        url = st.text_input("Website URL", placeholder="https://example.com/research")
        crawl_depth = st.slider("Crawl depth", 1, 5, 1)
        st.caption("Current MVP ingests the supplied page; crawl depth is staged for the crawler worker.")
        if st.button("Ingest website", disabled=not url, use_container_width=True):
            with st.status("Fetching, cleaning, chunking, and embedding page", expanded=True) as status:
                result = client.ingest_url(url)
                status.update(label=f"Indexed {result['chunks']} chunks", state="complete")
            st.toast("Website source indexed")

    with api_tab:
        endpoint = st.text_input("Endpoint", placeholder="https://api.example.com/items")
        json_path = st.text_input("JSON path", placeholder="Optional: data.0.body")
        title = st.text_input("Source title", placeholder="Optional display name")
        auth_mode = st.selectbox("Auth mode", ["None", "Bearer token", "API key header"], index=0)
        st.caption(f"Auth mode selected: {auth_mode}. Secure secret storage is part of the production hardening path.")
        if st.button("Connect and ingest API", disabled=not endpoint, use_container_width=True):
            with st.spinner("Reading API response and building embeddings"):
                result = client.ingest_api(endpoint, json_path or None, title or None)
            st.success(f"Indexed {result['chunks']} chunks")

    with note_tab:
        title = st.text_input("Note title", placeholder="Board meeting notes")
        text = st.text_area("Knowledge note", height=220, placeholder="Paste notes, transcripts, research snippets, or decisions.")
        if st.button("Save note to memory", disabled=not title or not text.strip(), use_container_width=True):
            result = client.ingest_note(title, text, source_tags)
            st.success(f"Saved note with {result['chunks']} chunks")

    glass_panel("Chunk Visualization", "Preview of the ingestion pipeline")
    st.markdown(
        """
        <div class="glass-card">
          <span class="tag">Extract text</span>
          <span class="tag">Normalize</span>
          <span class="tag">Chunk with overlap</span>
          <span class="tag">Embed vectors</span>
          <span class="tag">Upsert to Pinecone</span>
          <span class="tag">Persist citations</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def ask_ai(client: ApiClient) -> None:
    if "messages" not in st.session_state:
        st.session_state.messages = []

    left, right = st.columns([2.2, 0.9])
    with left:
        glass_panel("Ask AI", "Perplexity-style answer synthesis with citations")
        for message in st.session_state.messages:
            role = "You" if message["role"] == "user" else "Knowledge AI"
            with st.chat_message(message["role"]):
                st.markdown(f"**{role}**")
                st.markdown(message["content"])

        question = st.chat_input("Ask across your indexed knowledge...")
        top_k = st.session_state.get("retrieval_depth", 6)
        if question:
            st.session_state.messages.append({"role": "user", "content": question})
            with st.chat_message("user"):
                st.markdown(question)
            with st.chat_message("assistant"):
                placeholder = st.empty()
                with st.status("Retrieving evidence and reasoning with Claude", expanded=False):
                    result = client.query(question, top_k)
                streamed = ""
                for token in result["answer"].split(" "):
                    streamed += token + " "
                    placeholder.markdown(streamed)
                    time.sleep(0.01)
                st.caption(f"Confidence: {result['confidence']:.2f}")
                if result["citations"]:
                    with st.expander("Evidence panels", expanded=True):
                        for index, citation in enumerate(result["citations"], start=1):
                            st.markdown(f"**[{index}] {citation.get('title') or citation['uri']}**")
                            st.caption(f"{citation['uri']} · score {citation['score']:.3f}")
                            st.write(citation["excerpt"])
                st.download_button("Export answer", result["answer"], file_name="knowledge-answer.md")
            st.session_state.messages.append({"role": "assistant", "content": result["answer"]})

    with right:
        glass_panel("Retrieval Controls")
        st.session_state.retrieval_depth = st.slider("Retrieval depth", 3, 12, st.session_state.get("retrieval_depth", 6))
        st.multiselect("Semantic filters", ["PDF", "URL", "API", "Notes", "High confidence", "Recent"], default=[])
        st.selectbox("Conversation", ["Current thread", "Leadership brief", "Research sprint"])
        glass_panel("Follow-up Suggestions")
        for prompt in SUGGESTED_PROMPTS:
            st.button(prompt, use_container_width=True)
        glass_panel("Saved Prompts")
        tags(SAVED_PROMPTS)


def knowledge_graph(client: ApiClient) -> None:
    glass_panel("Knowledge Graph", "Interactive semantic map with zoom, pan, search, and node inspection")
    controls = st.columns([1.4, 1, 1])
    with controls[0]:
        st.text_input("Search within graph", placeholder="Search entity, topic, metric")
    with controls[1]:
        st.selectbox("Cluster by", ["Detected type", "Source", "Workspace", "Confidence"])
    with controls[2]:
        st.selectbox("Relationship focus", ["All", "co_occurs_with", "supports", "contradicts"])

    try:
        graph = client.graph()
    except Exception:
        graph = DEMO_GRAPH
    if not graph.get("nodes"):
        graph = DEMO_GRAPH
        st.info("Showing demo graph until indexed relationships are available.")
    component_html(render_interactive_graph(graph), height=700, scrolling=False)


def analytics() -> None:
    glass_panel("Analytics", "Retrieval quality, ingestion velocity, and citation coverage")
    c1, c2, c3 = st.columns(3)
    with c1:
        metric_card("Answer confidence", "0.82", "Demo trailing average")
    with c2:
        metric_card("Citation coverage", "94%", "Answers with evidence")
    with c3:
        metric_card("Hybrid recall", "Ready", "Keyword + vector roadmap")
    analytics_chart(ANALYTICS_SERIES)
    glass_panel("Knowledge Timelines")
    st.dataframe(pd.DataFrame(ANALYTICS_SERIES), use_container_width=True, hide_index=True)


def settings(client: ApiClient, connected: bool) -> str:
    glass_panel("Backend Settings", "Model providers, vector health, re-index controls, and diagnostics")
    new_base = st.text_input("API base URL", client.base_url)
    cols = st.columns(3)
    with cols[0]:
        st.selectbox("LLM provider", ["Claude", "OpenAI", "Local"])
    with cols[1]:
        st.selectbox("Embedding model", ["text-embedding-3-small", "text-embedding-3-large", "local-hash"])
    with cols[2]:
        st.selectbox("Vector database", ["Pinecone", "Local development store"])

    st.toggle("Enable streaming responses", value=True)
    st.toggle("Enable memory layer", value=True)
    st.toggle("Team collaboration", value=False)
    st.button("Re-index selected workspace", use_container_width=True)

    glass_panel("System Diagnostics")
    diagnostics = {
        "api_base": client.base_url,
        "api_connected": connected,
        "vector_db": "configured via backend environment",
        "workspace": st.session_state.get("workspace", "Personal Intelligence"),
    }
    st.json(diagnostics)

    glass_panel("Logs Console")
    st.code(
        "INFO  API health checked\nINFO  Streamlit session active\nINFO  Retrieval pipeline ready\nWARN  Docker not detected in this environment",
        language="text",
    )
    return new_base.rstrip("/")


def advanced() -> None:
    glass_panel("Advanced Intelligence Layer", "Roadmap modules exposed as production UI surfaces")
    features = [
        ("Multi-workspace", "Separate knowledge domains with isolated retrieval scopes."),
        ("Team collaboration", "Shared source review, comments, and activity attribution."),
        ("Role-based access", "Admin, analyst, viewer, and auditor permission modes."),
        ("AI agents", "Autonomous research, summarization, contradiction checks, and brief generation."),
        ("Document summaries", "Per-source abstract, key claims, entities, and open questions."),
        ("Semantic tagging", "Automatic topic, risk, metric, and owner labels."),
        ("Hybrid search", "Keyword scoring blended with vector similarity."),
        ("Memory layer", "Persistent conversation and user preference memory."),
    ]
    cols = st.columns(2)
    for index, (title, body) in enumerate(features):
        with cols[index % 2]:
            st.markdown(f'<div class="glass-card"><h3>{title}</h3><div class="muted">{body}</div></div>', unsafe_allow_html=True)
