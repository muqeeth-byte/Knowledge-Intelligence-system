from fastapi.testclient import TestClient

from backend.app.main import app


def main() -> None:
    with TestClient(app) as client:
        response = client.get("/api/health")
        response.raise_for_status()
        print(response.json())


if __name__ == "__main__":
    main()
