import hashlib
from dataclasses import dataclass

from sqlalchemy.orm import Session

from backend.app.models import Chunk, Document, Source, new_id
from backend.app.services.chunking import chunk_text, estimate_tokens
from backend.app.services.embeddings import EmbeddingService
from backend.app.services.graph import update_graph
from backend.app.services.vector_store import VectorStore


@dataclass
class IngestionResult:
    source_id: str
    document_id: str
    chunks: int


class IngestionService:
    def __init__(self, embeddings: EmbeddingService, vector_store: VectorStore):
        self.embeddings = embeddings
        self.vector_store = vector_store

    def ingest_text(self, db: Session, *, kind: str, uri: str, title: str | None, text: str) -> IngestionResult:
        content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        source = Source(kind=kind, uri=uri, title=title)
        document = Document(source=source, title=title, content_hash=content_hash)
        db.add(source)
        db.add(document)
        db.flush()

        chunks = chunk_text(text)
        vectors = self.embeddings.embed(chunks) if chunks else []
        vector_payload = []
        chunk_rows = []
        for index, (chunk, vector) in enumerate(zip(chunks, vectors)):
            chunk_id = new_id()
            vector_id = f"{document.id}:{index}"
            row = Chunk(
                id=chunk_id,
                document_id=document.id,
                source_id=source.id,
                chunk_index=index,
                text=chunk,
                token_estimate=estimate_tokens(chunk),
                vector_id=vector_id,
            )
            db.add(row)
            chunk_rows.append(row)
            vector_payload.append(
                (
                    vector_id,
                    vector,
                    {
                        "chunk_id": chunk_id,
                        "document_id": document.id,
                        "source_id": source.id,
                        "title": title or "",
                        "uri": uri,
                    },
                )
            )

        if vector_payload:
            self.vector_store.upsert(vector_payload)
        update_graph(db, source.id, chunks)
        db.commit()
        return IngestionResult(source_id=source.id, document_id=document.id, chunks=len(chunk_rows))
