from pydantic import BaseModel, HttpUrl


class UrlIngestRequest(BaseModel):
    url: HttpUrl


class ApiIngestRequest(BaseModel):
    endpoint: HttpUrl
    json_path: str | None = None
    title: str | None = None


class ManualNoteIngestRequest(BaseModel):
    title: str
    text: str
    tags: list[str] = []


class IngestResponse(BaseModel):
    source_id: str
    document_id: str
    chunks: int


class QueryRequest(BaseModel):
    question: str
    top_k: int = 6


class CitationOut(BaseModel):
    chunk_id: str
    source_id: str
    title: str | None
    uri: str
    score: float
    excerpt: str


class QueryResponse(BaseModel):
    answer: str
    confidence: float
    citations: list[CitationOut]


class GraphResponse(BaseModel):
    nodes: list[dict]
    edges: list[dict]


class DashboardStats(BaseModel):
    total_documents: int
    chunks_indexed: int
    graph_nodes: int
    graph_edges: int
    api_status: str
    recent_activity: list[dict]
