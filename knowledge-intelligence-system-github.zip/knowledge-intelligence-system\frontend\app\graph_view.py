import html
import json
import math
from typing import Any


PALETTE = {
    "concept": "#22d3ee",
    "entity": "#60a5fa",
    "metric": "#34d399",
    "risk": "#fb7185",
    "default": "#a78bfa",
}


def render_interactive_graph(graph: dict[str, Any]) -> str:
    nodes = graph.get("nodes", [])[:120]
    edges = graph.get("edges", [])[:260]
    for index, node in enumerate(nodes):
        node.setdefault("type", infer_type(node.get("label", "")))
        angle = (2 * math.pi * index) / max(1, len(nodes))
        node["x"] = 500 + math.cos(angle) * (120 + (index % 5) * 26)
        node["y"] = 310 + math.sin(angle) * (100 + (index % 4) * 30)
        node["color"] = PALETTE.get(node["type"], PALETTE["default"])

    payload = json.dumps({"nodes": nodes, "edges": edges})
    return f"""
    <div class="graph-shell">
      <div class="graph-toolbar">
        <input id="graphSearch" placeholder="Search graph nodes" />
        <span>Scroll to zoom · drag to pan · click nodes</span>
      </div>
      <svg id="kisGraph" viewBox="0 0 1000 620" role="img" aria-label="Knowledge graph"></svg>
      <aside id="nodePanel">
        <strong>Node details</strong>
        <p>Select a node to inspect connected relationships.</p>
      </aside>
    </div>
    <style>
      .graph-shell {{
        position: relative;
        min-height: 650px;
        border: 1px solid rgba(148, 163, 184, 0.20);
        border-radius: 14px;
        background:
          radial-gradient(circle at 30% 20%, rgba(34, 211, 238, 0.12), transparent 30%),
          rgba(2, 6, 23, 0.42);
        overflow: hidden;
      }}
      .graph-toolbar {{
        position: absolute;
        z-index: 5;
        left: 1rem;
        top: 1rem;
        right: 1rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        color: #94a3b8;
        font: 12px Inter, sans-serif;
      }}
      #graphSearch {{
        width: 280px;
        padding: 0.65rem 0.75rem;
        border: 1px solid rgba(148, 163, 184, 0.24);
        border-radius: 10px;
        color: #e5f4ff;
        background: rgba(2, 6, 23, 0.62);
        outline: none;
      }}
      #kisGraph {{ width: 100%; height: 650px; cursor: grab; }}
      #nodePanel {{
        position: absolute;
        right: 1rem;
        bottom: 1rem;
        width: 280px;
        padding: 1rem;
        border: 1px solid rgba(148, 163, 184, 0.22);
        border-radius: 14px;
        color: #e5f4ff;
        background: rgba(15, 23, 42, 0.78);
        backdrop-filter: blur(18px);
        font: 13px Inter, sans-serif;
      }}
      .edge {{ stroke: rgba(148, 163, 184, 0.34); stroke-width: 1.2; }}
      .edge.hot {{ stroke: rgba(34, 211, 238, 0.86); stroke-width: 2.4; }}
      .node {{ transition: opacity 160ms ease; cursor: pointer; }}
      .node circle {{ filter: drop-shadow(0 0 12px rgba(34, 211, 238, 0.22)); }}
      .node text {{ fill: #dbeafe; font: 12px Inter, sans-serif; pointer-events: none; }}
      .dim {{ opacity: 0.22; }}
    </style>
    <script>
      const data = {payload};
      const svg = document.getElementById("kisGraph");
      const panel = document.getElementById("nodePanel");
      const search = document.getElementById("graphSearch");
      const ns = "http://www.w3.org/2000/svg";
      const group = document.createElementNS(ns, "g");
      svg.appendChild(group);
      let scale = 1, tx = 0, ty = 0, dragging = false, start = [0, 0];

      function applyTransform() {{ group.setAttribute("transform", `translate(${{tx}} ${{ty}}) scale(${{scale}})`); }}
      function mk(tag, attrs) {{
        const el = document.createElementNS(ns, tag);
        for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, value);
        return el;
      }}
      const nodeById = new Map(data.nodes.map(n => [n.id, n]));
      data.edges.forEach(e => {{
        const s = nodeById.get(e.source), t = nodeById.get(e.target);
        if (!s || !t) return;
        const line = mk("line", {{x1:s.x, y1:s.y, x2:t.x, y2:t.y, class:"edge", "data-source":e.source, "data-target":e.target}});
        group.appendChild(line);
      }});
      data.nodes.forEach(n => {{
        const g = mk("g", {{class:"node", "data-id":n.id}});
        g.appendChild(mk("circle", {{cx:n.x, cy:n.y, r:10, fill:n.color, stroke:"rgba(255,255,255,0.55)", "stroke-width":1}}));
        const text = mk("text", {{x:n.x + 15, y:n.y + 4}});
        text.textContent = n.label || n.id;
        g.appendChild(text);
        g.addEventListener("click", () => selectNode(n));
        group.appendChild(g);
      }});
      function selectNode(n) {{
        const links = data.edges.filter(e => e.source === n.id || e.target === n.id);
        document.querySelectorAll(".edge").forEach(e => e.classList.toggle("hot", e.dataset.source === n.id || e.dataset.target === n.id));
        panel.innerHTML = `<strong>${{escapeHtml(n.label || n.id)}}</strong><p>Type: ${{escapeHtml(n.type || "default")}}</p><p>${{links.length}} connected relationships</p>`;
      }}
      function escapeHtml(value) {{ return String(value).replace(/[&<>"']/g, m => ({{"&":"&amp;","<":"&lt;",">":"&gt;","\\\"":"&quot;","'":"&#039;"}}[m])); }}
      svg.addEventListener("wheel", event => {{
        event.preventDefault();
        scale = Math.max(0.55, Math.min(2.6, scale + (event.deltaY < 0 ? 0.08 : -0.08)));
        applyTransform();
      }});
      svg.addEventListener("mousedown", event => {{ dragging = true; start = [event.clientX - tx, event.clientY - ty]; svg.style.cursor = "grabbing"; }});
      window.addEventListener("mouseup", () => {{ dragging = false; svg.style.cursor = "grab"; }});
      window.addEventListener("mousemove", event => {{ if (!dragging) return; tx = event.clientX - start[0]; ty = event.clientY - start[1]; applyTransform(); }});
      search.addEventListener("input", event => {{
        const q = event.target.value.toLowerCase();
        document.querySelectorAll(".node").forEach(el => el.classList.toggle("dim", q && !el.dataset.id.toLowerCase().includes(q)));
      }});
    </script>
    """


def infer_type(label: str) -> str:
    lowered = label.lower()
    if any(word in lowered for word in ["risk", "churn", "error", "issue"]):
        return "risk"
    if any(word in lowered for word in ["revenue", "score", "cost", "rate"]):
        return "metric"
    if any(word in lowered for word in ["customer", "user", "team", "company"]):
        return "entity"
    return "concept"
