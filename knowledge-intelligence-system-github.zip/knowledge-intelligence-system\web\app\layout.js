import "./globals.css";

export const metadata = {
  title: "Knowledge Intelligence System",
  description: "Premium AI SaaS interface for knowledge ingestion, semantic search, citations, and graph intelligence"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
