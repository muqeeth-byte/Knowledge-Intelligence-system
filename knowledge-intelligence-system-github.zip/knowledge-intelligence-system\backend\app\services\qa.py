from anthropic import Anthropic
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.config import Settings
from backend.app.models import Chunk, Citation, QueryLog, Source
from backend.app.schemas import CitationOut
from backend.app.services.embeddings import EmbeddingService
from backend.app.services.vector_store import VectorStore


class QAService:
    def __init__(self, settings: Settings, embeddings: EmbeddingService, vector_store: VectorStore):
        self.settings = settings
        self.embeddings = embeddings
        self.vector_store = vector_store
        self.client = Anthropic(api_key=settings.anthropic_api_key) if settings.anthropic_api_key else None

    def answer(self, db: Session, question: str, top_k: int = 6) -> dict:
        query_vector = self.embeddings.embed([question])[0]
        matches = self.vector_store.query(query_vector, top_k=top_k)
        chunk_ids = [match.metadata.get("chunk_id") for match in matches if match.metadata.get("chunk_id")]
        chunks = db.scalars(select(Chunk).where(Chunk.id.in_(chunk_ids))).all() if chunk_ids else []
        chunk_by_id = {chunk.id: chunk for chunk in chunks}

        citations: list[CitationOut] = []
        context_blocks = []
        for idx, match in enumerate(matches, start=1):
            chunk = chunk_by_id.get(match.metadata.get("chunk_id"))
            if not chunk:
                continue
            source = db.get(Source, chunk.source_id)
            title = source.title if source else match.metadata.get("title")
            uri = source.uri if source else match.metadata.get("uri", "")
            excerpt = chunk.text[:700]
            citations.append(
                CitationOut(
                    chunk_id=chunk.id,
                    source_id=chunk.source_id,
                    title=title,
                    uri=uri,
                    score=match.score,
                    excerpt=excerpt,
                )
            )
            context_blocks.append(f"[{idx}] {title or uri}\n{chunk.text}")

        confidence = self._confidence([citation.score for citation in citations])
        answer = self._synthesize(question, context_blocks, confidence)

        query_log = QueryLog(question=question, answer=answer, confidence=confidence)
        db.add(query_log)
        db.flush()
        for citation in citations:
            db.add(Citation(query_id=query_log.id, chunk_id=citation.chunk_id, score=citation.score, excerpt=citation.excerpt))
        db.commit()
        return {"answer": answer, "confidence": confidence, "citations": citations}

    def _synthesize(self, question: str, context_blocks: list[str], confidence: float) -> str:
        if not context_blocks:
            return "I could not find relevant knowledge in the indexed sources yet."

        context = "\n\n".join(context_blocks)
        if not self.client:
            return (
                "Claude is not configured, so here is a retrieval-only draft based on the most relevant indexed passages.\n\n"
                f"Question: {question}\n\n"
                f"Relevant evidence:\n{context[:3000]}\n\n"
                f"Estimated confidence: {confidence:.2f}"
            )

        message = self.client.messages.create(
            model=self.settings.claude_model,
            max_tokens=900,
            temperature=0.2,
            system=(
                "You answer using only the supplied context. Cite evidence with bracketed numbers like [1]. "
                "If the context is insufficient, say what is missing. Be concise and explicit about uncertainty."
            ),
            messages=[
                {
                    "role": "user",
                    "content": f"Question: {question}\n\nContext:\n{context}",
                }
            ],
        )
        return "\n".join(block.text for block in message.content if getattr(block, "type", "") == "text")

    def _confidence(self, scores: list[float]) -> float:
        if not scores:
            return 0.0
        top = max(scores)
        average = sum(scores[:3]) / min(3, len(scores))
        coverage = min(1.0, len(scores) / 5)
        return round(max(0.0, min(1.0, (top * 0.55) + (average * 0.30) + (coverage * 0.15))), 3)
