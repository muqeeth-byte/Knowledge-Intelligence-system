# Knowledge Intelligence System

An MVP Knowledge Intelligence System with multi-source ingestion, semantic search, Claude-powered answers, citation tracking, confidence scoring, and a knowledge graph view.

## Stack

- FastAPI backend
- Streamlit MVP UI
- PostgreSQL for metadata, chunks, citations, queries, and graph edges
- Pinecone for vector search when configured
- Claude via Anthropic for answer reasoning
- OpenAI embeddings when configured, deterministic local embeddings as a setup fallback

## Quick Start

1. Copy environment settings:

```powershell
Copy-Item .env.example .env
```

2. Start PostgreSQL:

```powershell
docker compose up -d postgres
```

3. Create and activate a virtual environment, then install dependencies:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

4. Run the API:

```powershell
uvicorn backend.app.main:app --reload --port 8000
```

5. Run the Streamlit UI in another terminal:

```powershell
streamlit run frontend/streamlit_app.py
```

Open Streamlit at [http://localhost:8501](http://localhost:8501).

## Notes

- Set `ANTHROPIC_API_KEY` to enable Claude answer synthesis.
- Set `OPENAI_API_KEY` for production-grade embeddings.
- Set `PINECONE_API_KEY` to use Pinecone. Without it, the backend uses an in-memory vector store for local development.
- The local fallback is useful for proving the workflow, but persisted Pinecone vectors should be used for real knowledge bases.
- See `ARCHITECTURE.md` for the data flow and production hardening path.

## Frontend

The Streamlit frontend is organized as a small app architecture:

- `frontend/streamlit_app.py`: app shell, sidebar navigation, topbar, workspace selector.
- `frontend/app/api_client.py`: FastAPI integration layer.
- `frontend/app/styles.py`: dark glassmorphism theme and interaction styling.
- `frontend/app/components.py`: reusable cards, activity feed, charts, empty states, loaders.
- `frontend/app/pages.py`: Dashboard, Ingest, Ask AI, Knowledge Graph, Analytics, Settings, Advanced.
- `frontend/app/graph_view.py`: interactive SVG graph with zoom, pan, search, and node detail panel.

If port `8501` is busy, run Streamlit on another port:

```powershell
streamlit run frontend/streamlit_app.py --server.port 8502
```

## Vercel Frontend

A Next.js version of the premium UI lives in `web/` and is deployable on Vercel.

Run locally:

```powershell
cd web
npm install
npm run dev -- -p 3000
```

Build for production:

```powershell
npm run build
```

Deploy to Vercel:

```powershell
npx vercel@latest deploy --prod
```

Set `NEXT_PUBLIC_API_BASE_URL` in Vercel to a public FastAPI backend URL when you deploy the backend. If it is left as localhost, the deployed UI will use its demo-ready surfaces but cannot call your local API from the public internet.
