# Architecture

## Flow

1. Sources arrive through PDF upload, URL fetch, or API fetch.
2. Extractors normalize the source into plain text.
3. Text is split into overlapping chunks.
4. Chunks are embedded with OpenAI embeddings when configured, otherwise a deterministic local embedder.
5. Vectors are written to Pinecone when configured, otherwise to the in-process development vector store.
6. Metadata, chunks, citations, query logs, and graph edges are persisted in PostgreSQL.
7. Queries are embedded, semantically matched, and sent to Claude with retrieved evidence.
8. Answers return citations and an evidence-derived confidence score.

## Core Modules

- `backend/app/services/extractors.py`: PDF, URL, and API text extraction.
- `backend/app/services/chunking.py`: text cleanup, chunking, and token estimates.
- `backend/app/services/embeddings.py`: OpenAI embeddings plus local fallback.
- `backend/app/services/vector_store.py`: Pinecone integration plus local fallback.
- `backend/app/services/qa.py`: retrieval, Claude synthesis, citations, and confidence scoring.
- `backend/app/services/graph.py`: lightweight co-occurrence graph extraction and serialization.
- `frontend/streamlit_app.py`: MVP ingestion, query, citations, confidence, and graph UI.

## Production Hardening Path

- Replace `Base.metadata.create_all` with Alembic migrations.
- Add background ingestion jobs for large PDFs and long URL crawls.
- Store original source files in object storage.
- Add user/workspace authorization boundaries.
- Add graph extraction with an entity/relation model instead of simple co-occurrence.
- Add evaluation sets for retrieval quality, answer faithfulness, and citation accuracy.
