def app_css() -> str:
    return """
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

      :root {
        --bg: #070a12;
        --panel: rgba(16, 23, 42, 0.72);
        --panel-strong: rgba(17, 24, 39, 0.92);
        --line: rgba(148, 163, 184, 0.20);
        --text: #eef4ff;
        --muted: #94a3b8;
        --cyan: #22d3ee;
        --blue: #60a5fa;
        --green: #34d399;
        --rose: #fb7185;
        --amber: #fbbf24;
      }

      html, body, [class*="css"] {
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      .stApp {
        color: var(--text);
        background:
          radial-gradient(circle at 16% 8%, rgba(34, 211, 238, 0.18), transparent 32%),
          radial-gradient(circle at 86% 10%, rgba(96, 165, 250, 0.16), transparent 28%),
          linear-gradient(135deg, #050712 0%, #0b1020 52%, #07111f 100%);
      }

      [data-testid="stSidebar"] {
        background: rgba(3, 7, 18, 0.82);
        border-right: 1px solid var(--line);
        backdrop-filter: blur(22px);
      }

      [data-testid="stHeader"] {
        background: rgba(7, 10, 18, 0.50);
        border-bottom: 1px solid rgba(148, 163, 184, 0.10);
        backdrop-filter: blur(18px);
      }

      [data-testid="stToolbar"] { display: none; }

      .block-container {
        max-width: 1500px;
        padding-top: 1.3rem;
        padding-bottom: 4rem;
      }

      h1, h2, h3 { letter-spacing: 0; }
      h1 { font-size: 2.4rem; font-weight: 800; margin-bottom: 0.2rem; }
      h2 { font-size: 1.45rem; font-weight: 750; }
      h3 { font-size: 1.05rem; font-weight: 700; }
      p, label, span { color: inherit; }

      .topbar {
        position: sticky;
        top: 0;
        z-index: 40;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.85rem 1rem;
        margin-bottom: 1rem;
        border: 1px solid var(--line);
        border-radius: 14px;
        background: rgba(15, 23, 42, 0.58);
        box-shadow: 0 24px 80px rgba(0, 0, 0, 0.22);
        backdrop-filter: blur(18px);
      }

      .brand {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        font-weight: 800;
        color: var(--text);
      }

      .brand-mark {
        display: grid;
        width: 38px;
        height: 38px;
        place-items: center;
        border: 1px solid rgba(34, 211, 238, 0.35);
        border-radius: 12px;
        background: linear-gradient(145deg, rgba(34, 211, 238, 0.22), rgba(96, 165, 250, 0.12));
        color: #dffbff;
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.16), 0 14px 36px rgba(34,211,238,0.10);
      }

      .command-pill {
        min-width: 230px;
        padding: 0.72rem 0.9rem;
        border: 1px solid var(--line);
        border-radius: 999px;
        color: var(--muted);
        background: rgba(2, 6, 23, 0.42);
        text-align: left;
      }

      .glass-card {
        position: relative;
        height: 100%;
        padding: 1rem;
        border: 1px solid var(--line);
        border-radius: 14px;
        background: var(--panel);
        box-shadow: 0 20px 70px rgba(0,0,0,0.24);
        backdrop-filter: blur(20px);
        transition: transform 180ms ease, border-color 180ms ease, background 180ms ease;
        overflow: hidden;
      }

      .glass-card:hover {
        transform: translateY(-2px);
        border-color: rgba(34, 211, 238, 0.34);
        background: rgba(18, 26, 45, 0.82);
      }

      .metric-value {
        margin-top: 0.5rem;
        font-size: 2rem;
        font-weight: 800;
        color: #f8fbff;
      }

      .metric-label, .muted {
        color: var(--muted);
        font-size: 0.85rem;
      }

      .status-dot {
        display: inline-block;
        width: 0.55rem;
        height: 0.55rem;
        margin-right: 0.4rem;
        border-radius: 999px;
        background: var(--green);
        box-shadow: 0 0 18px rgba(52, 211, 153, 0.8);
      }

      .section-title {
        display: flex;
        align-items: end;
        justify-content: space-between;
        margin: 1.4rem 0 0.75rem;
      }

      .tag {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.28rem 0.58rem;
        margin: 0.12rem;
        border: 1px solid rgba(148, 163, 184, 0.18);
        border-radius: 999px;
        color: #dbeafe;
        background: rgba(96, 165, 250, 0.11);
        font-size: 0.78rem;
      }

      .empty-state {
        padding: 2.2rem;
        border: 1px dashed rgba(148, 163, 184, 0.28);
        border-radius: 14px;
        text-align: center;
        background: rgba(15, 23, 42, 0.38);
      }

      .skeleton {
        min-height: 92px;
        border-radius: 14px;
        background: linear-gradient(90deg, rgba(148,163,184,0.08), rgba(255,255,255,0.16), rgba(148,163,184,0.08));
        background-size: 220% 100%;
        animation: shimmer 1.4s ease infinite;
      }

      @keyframes shimmer { from { background-position: 220% 0; } to { background-position: -220% 0; } }

      .floating-action {
        position: fixed;
        right: 2rem;
        bottom: 1.8rem;
        z-index: 90;
        padding: 0.82rem 1rem;
        border: 1px solid rgba(34, 211, 238, 0.28);
        border-radius: 999px;
        color: #e0faff;
        background: rgba(14, 165, 233, 0.16);
        box-shadow: 0 22px 80px rgba(14, 165, 233, 0.22);
        backdrop-filter: blur(18px);
      }

      .stButton > button, .stDownloadButton > button {
        border: 1px solid rgba(34, 211, 238, 0.30);
        border-radius: 10px;
        background: linear-gradient(135deg, rgba(34, 211, 238, 0.20), rgba(96, 165, 250, 0.20));
        color: #eff6ff;
        font-weight: 650;
        transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
      }

      .stButton > button:hover, .stDownloadButton > button:hover {
        transform: translateY(-1px);
        border-color: rgba(34, 211, 238, 0.58);
        box-shadow: 0 18px 48px rgba(34, 211, 238, 0.14);
      }

      .stTextInput input, .stTextArea textarea, .stSelectbox div[data-baseweb="select"], .stMultiSelect div[data-baseweb="select"] {
        border-color: rgba(148, 163, 184, 0.22) !important;
        border-radius: 10px !important;
        background: rgba(2, 6, 23, 0.40) !important;
        color: #eef4ff !important;
      }

      [data-testid="stFileUploader"] section {
        border: 1px dashed rgba(34, 211, 238, 0.34);
        border-radius: 14px;
        background: rgba(15, 23, 42, 0.38);
      }

      div[data-testid="stTabs"] button {
        color: var(--muted);
      }

      div[data-testid="stTabs"] button[aria-selected="true"] {
        color: #e0faff;
        border-bottom-color: var(--cyan);
      }

      @media (max-width: 900px) {
        .topbar { position: relative; flex-direction: column; align-items: stretch; }
        .command-pill { min-width: auto; }
        .metric-value { font-size: 1.55rem; }
      }
    </style>
    """
